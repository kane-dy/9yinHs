from utils.key_tool import key_tool

from utils.utils_tools import path


HWND_CBTEXT = ""
KEYTOOL = key_tool(path())

#幸运硬币
TASK_XYYB = '659b1800d8f86ea303bbeea989e2931e'
#运镖
TASK_YB = 'a3f845961ffca5b214b7eb0b0c4d9061'